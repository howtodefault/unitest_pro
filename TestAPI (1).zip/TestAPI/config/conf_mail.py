#发送邮件配置参数
#发送服务器
Smtp_Server = 'smtp.exmail.qq.com'
#发送人
Smtp_Sender = 'dong.chen@zhihuotech.com'
#发送人密码
Smtp_Sender_Password = 'Anchao0212'
#接收人
Smtp_Receiver = ['dong.chen@zhihuotech.com']
#接收组
Smtp_Receiver_pre = ['chao.li@zhihuotech.com']