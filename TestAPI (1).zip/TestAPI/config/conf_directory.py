#测试用例及报告路径配置参数
test_dir = 'C:/TestAPI/test_case/small_program'
report_dir = 'C:/TestAPI/test_report/'
log_dir='C:/TestAPI/test_log'